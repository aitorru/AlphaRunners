# Debug folder

Aqui se guardan los archivos binarios despues de compilar.

# Como compilar
```bash
make build
```
Debes asegurarte que tienes make instalado.
